class Sessao:
    def __init__(self, id=None, cinema_id=None, filme_id=None, data="", horario="", sala=""):
        self.id = id
        self.cinema_id = cinema_id
        self.filme_id = filme_id
        self.data = data
        self.horario = horario
        self.sala = sala

    def __repr__(self):
        return f"Sessao(id={self.id}, data='{self.data}', horario='{self.horario}', sala='{self.sala}')"
