class Filme:
    def __init__(self, id=None, titulo="", duracao_min=0, diretor="", elenco="", genero_id=None):
        self.id = id
        self.titulo = titulo
        self.duracao_min = duracao_min
        self.diretor = diretor
        self.elenco = elenco
        self.genero_id = genero_id

    def __repr__(self):
        return f"Filme(id={self.id}, titulo='{self.titulo}', diretor='{self.diretor}')"
