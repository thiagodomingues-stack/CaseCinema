class Genero:
    def __init__(self, id=None, descricao=""):
        self.id = id
        self.descricao = descricao

    def __repr__(self):
        return f"Genero(id={self.id}, descricao='{self.descricao}')"
