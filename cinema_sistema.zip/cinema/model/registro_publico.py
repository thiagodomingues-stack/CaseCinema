class RegistroPublico:
    def __init__(self, id=None, sessao_id=None, quantidade=0, data_registro=""):
        self.id = id
        self.sessao_id = sessao_id
        self.quantidade = quantidade
        self.data_registro = data_registro

    def __repr__(self):
        return f"RegistroPublico(sessao_id={self.sessao_id}, quantidade={self.quantidade})"
