class Cinema:
    def __init__(self, id=None, nome="", cidade="", estado="", endereco="", capacidade=0):
        self.id = id
        self.nome = nome
        self.cidade = cidade
        self.estado = estado
        self.endereco = endereco
        self.capacidade = capacidade

    def __repr__(self):
        return f"Cinema(id={self.id}, nome='{self.nome}', cidade='{self.cidade}')"
