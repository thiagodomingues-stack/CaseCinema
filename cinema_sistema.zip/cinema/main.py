import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from db.conexao import inicializar_banco
from view.cinema_view import menu_cinema
from view.filme_view import menu_filme
from view.sessao_view import menu_sessao
from view.registro_publico_view import menu_registro_publico
from view.genero_view import menu_genero

def main():
    inicializar_banco()
    print("=" * 45)
    print("   SISTEMA DE GERENCIAMENTO DE CINEMAS")
    print("=" * 45)

    while True:
        print("\n===== MENU PRINCIPAL =====")
        print("1. Cinemas")
        print("2. Filmes")
        print("3. Gêneros")
        print("4. Sessões")
        print("5. Registro de Público")
        print("0. Sair")
        opcao = input("Escolha: ").strip()

        if opcao == "1":
            menu_cinema()
        elif opcao == "2":
            menu_filme()
        elif opcao == "3":
            menu_genero()
        elif opcao == "4":
            menu_sessao()
        elif opcao == "5":
            menu_registro_publico()
        elif opcao == "0":
            print("\nEncerrando sistema. Até logo!")
            break
        else:
            print("Opção inválida. Tente novamente.")

if __name__ == "__main__":
    main()
