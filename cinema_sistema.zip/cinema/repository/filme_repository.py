import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from db.conexao import get_connection
from model.filme import Filme

class FilmeRepository:

    def salvar(self, filme: Filme) -> Filme:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO filme (titulo, duracao_min, diretor, elenco, genero_id) VALUES (?, ?, ?, ?, ?)",
            (filme.titulo, filme.duracao_min, filme.diretor, filme.elenco, filme.genero_id)
        )
        conn.commit()
        filme.id = cursor.lastrowid
        conn.close()
        return filme

    def listar_todos(self) -> list:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT f.*, g.descricao as genero_descricao
            FROM filme f
            LEFT JOIN genero g ON f.genero_id = g.id
        """)
        rows = cursor.fetchall()
        conn.close()
        filmes = []
        for r in rows:
            f = Filme(id=r["id"], titulo=r["titulo"], duracao_min=r["duracao_min"],
                      diretor=r["diretor"], elenco=r["elenco"], genero_id=r["genero_id"])
            f.genero_descricao = r["genero_descricao"]
            filmes.append(f)
        return filmes

    def buscar_por_id(self, filme_id: int):
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT f.*, g.descricao as genero_descricao
            FROM filme f
            LEFT JOIN genero g ON f.genero_id = g.id
            WHERE f.id = ?
        """, (filme_id,))
        r = cursor.fetchone()
        conn.close()
        if r:
            f = Filme(id=r["id"], titulo=r["titulo"], duracao_min=r["duracao_min"],
                      diretor=r["diretor"], elenco=r["elenco"], genero_id=r["genero_id"])
            f.genero_descricao = r["genero_descricao"]
            return f
        return None

    def excluir(self, filme_id: int) -> bool:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("DELETE FROM filme WHERE id = ?", (filme_id,))
        conn.commit()
        alterados = cursor.rowcount
        conn.close()
        return alterados > 0
