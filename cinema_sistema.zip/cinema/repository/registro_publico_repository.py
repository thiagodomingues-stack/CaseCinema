import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from db.conexao import get_connection
from model.registro_publico import RegistroPublico

class RegistroPublicoRepository:

    def salvar(self, registro: RegistroPublico) -> RegistroPublico:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO registro_publico (sessao_id, quantidade, data_registro) VALUES (?, ?, ?)",
            (registro.sessao_id, registro.quantidade, registro.data_registro)
        )
        conn.commit()
        registro.id = cursor.lastrowid
        conn.close()
        return registro

    def total_por_sessao(self, sessao_id: int) -> int:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute(
            "SELECT COALESCE(SUM(quantidade), 0) as total FROM registro_publico WHERE sessao_id = ?",
            (sessao_id,)
        )
        r = cursor.fetchone()
        conn.close()
        return r["total"] if r else 0

    def total_por_filme(self, filme_id: int) -> int:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT COALESCE(SUM(rp.quantidade), 0) as total
            FROM registro_publico rp
            JOIN sessao s ON rp.sessao_id = s.id
            WHERE s.filme_id = ?
        """, (filme_id,))
        r = cursor.fetchone()
        conn.close()
        return r["total"] if r else 0

    def total_por_cinema(self, cinema_id: int) -> int:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT COALESCE(SUM(rp.quantidade), 0) as total
            FROM registro_publico rp
            JOIN sessao s ON rp.sessao_id = s.id
            WHERE s.cinema_id = ?
        """, (cinema_id,))
        r = cursor.fetchone()
        conn.close()
        return r["total"] if r else 0

    def listar_por_sessao(self, sessao_id: int) -> list:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute(
            "SELECT * FROM registro_publico WHERE sessao_id = ? ORDER BY data_registro",
            (sessao_id,)
        )
        rows = cursor.fetchall()
        conn.close()
        return [RegistroPublico(id=r["id"], sessao_id=r["sessao_id"],
                                quantidade=r["quantidade"], data_registro=r["data_registro"])
                for r in rows]
