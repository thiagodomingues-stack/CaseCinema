import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from db.conexao import get_connection
from model.genero import Genero

class GeneroRepository:

    def salvar(self, genero: Genero) -> Genero:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("INSERT INTO genero (descricao) VALUES (?)", (genero.descricao,))
        conn.commit()
        genero.id = cursor.lastrowid
        conn.close()
        return genero

    def listar_todos(self) -> list:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM genero ORDER BY descricao")
        rows = cursor.fetchall()
        conn.close()
        return [Genero(id=r["id"], descricao=r["descricao"]) for r in rows]

    def buscar_por_id(self, genero_id: int):
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM genero WHERE id = ?", (genero_id,))
        r = cursor.fetchone()
        conn.close()
        return Genero(id=r["id"], descricao=r["descricao"]) if r else None
