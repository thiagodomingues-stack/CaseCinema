import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from db.conexao import get_connection
from model.sessao import Sessao

class SessaoRepository:

    def salvar(self, sessao: Sessao) -> Sessao:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO sessao (cinema_id, filme_id, data, horario, sala) VALUES (?, ?, ?, ?, ?)",
            (sessao.cinema_id, sessao.filme_id, sessao.data, sessao.horario, sessao.sala)
        )
        conn.commit()
        sessao.id = cursor.lastrowid
        conn.close()
        return sessao

    def listar_por_cinema(self, cinema_id: int) -> list:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT s.*, f.titulo as filme_titulo, f.duracao_min, c.nome as cinema_nome
            FROM sessao s
            JOIN filme f ON s.filme_id = f.id
            JOIN cinema c ON s.cinema_id = c.id
            WHERE s.cinema_id = ?
            ORDER BY s.data, s.horario
        """, (cinema_id,))
        rows = cursor.fetchall()
        conn.close()
        sessoes = []
        for r in rows:
            s = Sessao(id=r["id"], cinema_id=r["cinema_id"], filme_id=r["filme_id"],
                       data=r["data"], horario=r["horario"], sala=r["sala"])
            s.filme_titulo = r["filme_titulo"]
            s.cinema_nome = r["cinema_nome"]
            sessoes.append(s)
        return sessoes

    def listar_todas(self) -> list:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT s.*, f.titulo as filme_titulo, c.nome as cinema_nome
            FROM sessao s
            JOIN filme f ON s.filme_id = f.id
            JOIN cinema c ON s.cinema_id = c.id
            ORDER BY s.data, s.horario
        """)
        rows = cursor.fetchall()
        conn.close()
        sessoes = []
        for r in rows:
            s = Sessao(id=r["id"], cinema_id=r["cinema_id"], filme_id=r["filme_id"],
                       data=r["data"], horario=r["horario"], sala=r["sala"])
            s.filme_titulo = r["filme_titulo"]
            s.cinema_nome = r["cinema_nome"]
            sessoes.append(s)
        return sessoes

    def buscar_por_id(self, sessao_id: int):
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT s.*, f.titulo as filme_titulo, c.nome as cinema_nome
            FROM sessao s
            JOIN filme f ON s.filme_id = f.id
            JOIN cinema c ON s.cinema_id = c.id
            WHERE s.id = ?
        """, (sessao_id,))
        r = cursor.fetchone()
        conn.close()
        if r:
            s = Sessao(id=r["id"], cinema_id=r["cinema_id"], filme_id=r["filme_id"],
                       data=r["data"], horario=r["horario"], sala=r["sala"])
            s.filme_titulo = r["filme_titulo"]
            s.cinema_nome = r["cinema_nome"]
            return s
        return None

    def verificar_conflito(self, cinema_id, sala, data, horario, duracao_min, sessao_id=None) -> bool:
        """Verifica se há conflito de horário na sala/cinema para a data informada."""
        conn = get_connection()
        cursor = conn.cursor()
        query = """
            SELECT s.id, s.horario, f.duracao_min
            FROM sessao s
            JOIN filme f ON s.filme_id = f.id
            WHERE s.cinema_id = ? AND s.sala = ? AND s.data = ?
        """
        params = [cinema_id, sala, data]
        if sessao_id:
            query += " AND s.id != ?"
            params.append(sessao_id)
        cursor.execute(query, params)
        rows = cursor.fetchall()
        conn.close()

        from datetime import datetime, timedelta
        intervalo_min = 20
        nova_inicio = datetime.strptime(horario, "%H:%M")
        nova_fim = nova_inicio + timedelta(minutes=duracao_min + intervalo_min)

        for r in rows:
            ex_inicio = datetime.strptime(r["horario"], "%H:%M")
            ex_fim = ex_inicio + timedelta(minutes=r["duracao_min"] + intervalo_min)
            if not (nova_fim <= ex_inicio or nova_inicio >= ex_fim):
                return True
        return False

    def excluir(self, sessao_id: int) -> bool:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("DELETE FROM sessao WHERE id = ?", (sessao_id,))
        conn.commit()
        alterados = cursor.rowcount
        conn.close()
        return alterados > 0
