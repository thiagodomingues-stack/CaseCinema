import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from db.conexao import get_connection
from model.cinema import Cinema

class CinemaRepository:

    def salvar(self, cinema: Cinema) -> Cinema:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO cinema (nome, cidade, estado, endereco, capacidade) VALUES (?, ?, ?, ?, ?)",
            (cinema.nome, cinema.cidade, cinema.estado, cinema.endereco, cinema.capacidade)
        )
        conn.commit()
        cinema.id = cursor.lastrowid
        conn.close()
        return cinema

    def listar_todos(self) -> list:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM cinema")
        rows = cursor.fetchall()
        conn.close()
        return [Cinema(id=r["id"], nome=r["nome"], cidade=r["cidade"],
                       estado=r["estado"], endereco=r["endereco"],
                       capacidade=r["capacidade"]) for r in rows]

    def buscar_por_id(self, cinema_id: int):
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM cinema WHERE id = ?", (cinema_id,))
        r = cursor.fetchone()
        conn.close()
        if r:
            return Cinema(id=r["id"], nome=r["nome"], cidade=r["cidade"],
                          estado=r["estado"], endereco=r["endereco"],
                          capacidade=r["capacidade"])
        return None

    def atualizar(self, cinema: Cinema) -> bool:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute(
            "UPDATE cinema SET nome=?, cidade=?, estado=?, endereco=?, capacidade=? WHERE id=?",
            (cinema.nome, cinema.cidade, cinema.estado, cinema.endereco, cinema.capacidade, cinema.id)
        )
        conn.commit()
        alterados = cursor.rowcount
        conn.close()
        return alterados > 0

    def excluir(self, cinema_id: int) -> bool:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("DELETE FROM cinema WHERE id = ?", (cinema_id,))
        conn.commit()
        alterados = cursor.rowcount
        conn.close()
        return alterados > 0
