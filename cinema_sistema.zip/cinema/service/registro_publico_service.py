import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from datetime import date
from model.registro_publico import RegistroPublico
from repository.registro_publico_repository import RegistroPublicoRepository
from repository.sessao_repository import SessaoRepository
from repository.cinema_repository import CinemaRepository

class RegistroPublicoService:

    def __init__(self):
        self.repo = RegistroPublicoRepository()
        self.sessao_repo = SessaoRepository()
        self.cinema_repo = CinemaRepository()

    def registrar(self, sessao_id, quantidade):
        sessao_id = int(sessao_id)
        try:
            quantidade = int(quantidade)
            if quantidade <= 0:
                raise ValueError("Quantidade deve ser positiva.")
        except (ValueError, TypeError):
            raise ValueError("Quantidade inválida.")

        sessao = self.sessao_repo.buscar_por_id(sessao_id)
        if not sessao:
            raise ValueError("Sessão não encontrada.")

        cinema = self.cinema_repo.buscar_por_id(sessao.cinema_id)
        total_atual = self.repo.total_por_sessao(sessao_id)
        if cinema and (total_atual + quantidade) > cinema.capacidade:
            raise ValueError(
                f"Capacidade excedida! Capacidade: {cinema.capacidade}, "
                f"Ocupado: {total_atual}, Tentando adicionar: {quantidade}."
            )

        registro = RegistroPublico(
            sessao_id=sessao_id,
            quantidade=quantidade,
            data_registro=str(date.today())
        )
        return self.repo.salvar(registro)

    def total_por_sessao(self, sessao_id):
        return self.repo.total_por_sessao(int(sessao_id))

    def total_por_filme(self, filme_id):
        return self.repo.total_por_filme(int(filme_id))

    def total_por_cinema(self, cinema_id):
        return self.repo.total_por_cinema(int(cinema_id))

    def listar_por_sessao(self, sessao_id):
        return self.repo.listar_por_sessao(int(sessao_id))
