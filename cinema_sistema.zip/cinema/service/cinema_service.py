import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from model.cinema import Cinema
from repository.cinema_repository import CinemaRepository

class CinemaService:

    def __init__(self):
        self.repo = CinemaRepository()

    def cadastrar(self, nome, cidade, estado, endereco, capacidade):
        if not nome or not cidade or not estado or not endereco:
            raise ValueError("Todos os campos obrigatórios devem ser preenchidos.")
        try:
            capacidade = int(capacidade)
            if capacidade <= 0:
                raise ValueError("Capacidade deve ser um número positivo.")
        except (ValueError, TypeError):
            raise ValueError("Capacidade deve ser um número inteiro positivo.")

        cinema = Cinema(nome=nome.strip(), cidade=cidade.strip(), estado=estado.strip().upper(),
                        endereco=endereco.strip(), capacidade=capacidade)
        return self.repo.salvar(cinema)

    def listar(self):
        return self.repo.listar_todos()

    def buscar(self, cinema_id):
        cinema = self.repo.buscar_por_id(cinema_id)
        if not cinema:
            raise ValueError(f"Cinema com ID {cinema_id} não encontrado.")
        return cinema

    def atualizar(self, cinema_id, nome, cidade, estado, endereco, capacidade):
        cinema = self.buscar(cinema_id)
        cinema.nome = nome.strip()
        cinema.cidade = cidade.strip()
        cinema.estado = estado.strip().upper()
        cinema.endereco = endereco.strip()
        cinema.capacidade = int(capacidade)
        self.repo.atualizar(cinema)
        return cinema

    def excluir(self, cinema_id):
        if not self.repo.excluir(cinema_id):
            raise ValueError(f"Cinema com ID {cinema_id} não encontrado.")
