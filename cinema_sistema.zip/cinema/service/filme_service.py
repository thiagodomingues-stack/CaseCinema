import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from model.filme import Filme
from repository.filme_repository import FilmeRepository
from repository.genero_repository import GeneroRepository

class FilmeService:

    def __init__(self):
        self.repo = FilmeRepository()
        self.genero_repo = GeneroRepository()

    def cadastrar(self, titulo, duracao_min, diretor, elenco, genero_id):
        if not titulo or not diretor:
            raise ValueError("Título e diretor são obrigatórios.")
        try:
            duracao_min = int(duracao_min)
            if duracao_min <= 0:
                raise ValueError("Duração deve ser positiva.")
        except (ValueError, TypeError):
            raise ValueError("Duração deve ser um número inteiro positivo.")

        genero_id = int(genero_id) if genero_id else None
        if genero_id and not self.genero_repo.buscar_por_id(genero_id):
            raise ValueError("Gênero inválido.")

        filme = Filme(titulo=titulo.strip(), duracao_min=duracao_min,
                      diretor=diretor.strip(), elenco=elenco, genero_id=genero_id)
        return self.repo.salvar(filme)

    def listar(self):
        return self.repo.listar_todos()

    def buscar(self, filme_id):
        filme = self.repo.buscar_por_id(filme_id)
        if not filme:
            raise ValueError(f"Filme com ID {filme_id} não encontrado.")
        return filme

    def excluir(self, filme_id):
        if not self.repo.excluir(filme_id):
            raise ValueError(f"Filme com ID {filme_id} não encontrado.")
