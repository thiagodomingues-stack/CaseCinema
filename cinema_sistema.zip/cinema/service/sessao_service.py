import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from model.sessao import Sessao
from repository.sessao_repository import SessaoRepository
from repository.cinema_repository import CinemaRepository
from repository.filme_repository import FilmeRepository

class SessaoService:

    def __init__(self):
        self.repo = SessaoRepository()
        self.cinema_repo = CinemaRepository()
        self.filme_repo = FilmeRepository()

    def cadastrar(self, cinema_id, filme_id, data, horario, sala):
        cinema_id = int(cinema_id)
        filme_id = int(filme_id)

        if not self.cinema_repo.buscar_por_id(cinema_id):
            raise ValueError("Cinema não encontrado.")
        filme = self.filme_repo.buscar_por_id(filme_id)
        if not filme:
            raise ValueError("Filme não encontrado.")
        if not data or not horario or not sala:
            raise ValueError("Data, horário e sala são obrigatórios.")

        if self.repo.verificar_conflito(cinema_id, sala, data, horario, filme.duracao_min):
            raise ValueError("Conflito de horário: já existe sessão nessa sala/horário (considere intervalo de 20 min).")

        sessao = Sessao(cinema_id=cinema_id, filme_id=filme_id,
                        data=data, horario=horario, sala=sala.strip())
        return self.repo.salvar(sessao)

    def listar_por_cinema(self, cinema_id):
        return self.repo.listar_por_cinema(int(cinema_id))

    def listar_todas(self):
        return self.repo.listar_todas()

    def buscar(self, sessao_id):
        sessao = self.repo.buscar_por_id(int(sessao_id))
        if not sessao:
            raise ValueError(f"Sessão com ID {sessao_id} não encontrada.")
        return sessao

    def excluir(self, sessao_id):
        if not self.repo.excluir(int(sessao_id)):
            raise ValueError(f"Sessão com ID {sessao_id} não encontrada.")
