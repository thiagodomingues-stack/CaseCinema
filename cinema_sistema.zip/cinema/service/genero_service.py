import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from model.genero import Genero
from repository.genero_repository import GeneroRepository

class GeneroService:

    def __init__(self):
        self.repo = GeneroRepository()

    def cadastrar(self, descricao):
        if not descricao:
            raise ValueError("Descrição do gênero é obrigatória.")
        genero = Genero(descricao=descricao.strip())
        return self.repo.salvar(genero)

    def listar(self):
        return self.repo.listar_todos()
