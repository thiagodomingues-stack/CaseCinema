import sqlite3
import os

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'cinema.db')

def get_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def inicializar_banco():
    conn = get_connection()
    cursor = conn.cursor()

    cursor.executescript("""
        CREATE TABLE IF NOT EXISTS cinema (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            cidade TEXT NOT NULL,
            estado TEXT NOT NULL,
            endereco TEXT NOT NULL,
            capacidade INTEGER NOT NULL
        );

        CREATE TABLE IF NOT EXISTS genero (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            descricao TEXT NOT NULL UNIQUE
        );

        CREATE TABLE IF NOT EXISTS filme (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            titulo TEXT NOT NULL,
            duracao_min INTEGER NOT NULL,
            diretor TEXT NOT NULL,
            elenco TEXT,
            genero_id INTEGER,
            FOREIGN KEY (genero_id) REFERENCES genero(id)
        );

        CREATE TABLE IF NOT EXISTS sessao (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            cinema_id INTEGER NOT NULL,
            filme_id INTEGER NOT NULL,
            data TEXT NOT NULL,
            horario TEXT NOT NULL,
            sala TEXT NOT NULL,
            FOREIGN KEY (cinema_id) REFERENCES cinema(id),
            FOREIGN KEY (filme_id) REFERENCES filme(id)
        );

        CREATE TABLE IF NOT EXISTS registro_publico (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            sessao_id INTEGER NOT NULL,
            quantidade INTEGER NOT NULL,
            data_registro TEXT NOT NULL,
            FOREIGN KEY (sessao_id) REFERENCES sessao(id)
        );
    """)

    conn.commit()
    conn.close()
