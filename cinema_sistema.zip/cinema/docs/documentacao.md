# Sistema de Gerenciamento de Rede de Cinemas

## 1. Levantamento de Requisitos

### Requisitos Funcionais
- RF01: Cadastrar, listar, atualizar e excluir cinemas
- RF02: Cadastrar, listar e excluir filmes (com gênero, diretor e elenco)
- RF03: Cadastrar e listar gêneros de filmes
- RF04: Agendar sessões de filmes por cinema, data, horário e sala
- RF05: Verificar conflito de horário com intervalo mínimo de 20 minutos entre sessões
- RF06: Registrar público diário por sessão
- RF07: Consultar totalização de público por sessão, por filme e por cinema
- RF08: Validar capacidade máxima do cinema ao registrar público

### Regras de Negócio
- RN01: Uma sessão não pode ser agendada se houver conflito de horário na mesma sala (duração + 20 min de intervalo)
- RN02: O total de público registrado em uma sessão não pode ultrapassar a capacidade do cinema
- RN03: Todo filme deve ter título e diretor preenchidos
- RN04: Todo cinema deve ter nome, cidade, estado, endereço e capacidade preenchidos
- RN05: Uma sessão exige cinema, filme, data, horário e sala válidos

---

## 2. Diagrama de Casos de Uso

```
Atores: Funcionário/Administrador | Espectador

Funcionário/Administrador:
  - Cadastrar Cinema
  - Atualizar Cinema
  - Excluir Cinema
  - Cadastrar Filme
  - Cadastrar Gênero
  - Agendar Sessão
  - Registrar Público da Sessão
  - Consultar Totalizações (por sessão / filme / cinema)

Espectador:
  - Consultar Sessões por Cinema
  - Consultar Filmes em Cartaz
```

---

## 3. Diagrama de Classes do Domínio

```
Cinema
  - id: int
  - nome: str
  - cidade: str
  - estado: str
  - endereco: str
  - capacidade: int
  1 --- * Sessao

Genero
  - id: int
  - descricao: str
  1 --- * Filme

Filme
  - id: int
  - titulo: str
  - duracao_min: int
  - diretor: str
  - elenco: str
  - genero_id: int
  1 --- * Sessao

Sessao
  - id: int
  - cinema_id: int
  - filme_id: int
  - data: str
  - horario: str
  - sala: str
  1 --- * RegistroPublico

RegistroPublico
  - id: int
  - sessao_id: int
  - quantidade: int
  - data_registro: str
```

---

## 4. Diagrama de Atividade — Agendar Sessão

```
[Início]
   |
   v
Funcionário informa: cinema, filme, data, horário, sala
   |
   v
Sistema valida existência do cinema e do filme
   |
   v
Sistema verifica conflito de horário na sala
   |------> [Conflito encontrado] --> Exibe erro --> [Fim]
   |
   v
Sistema persiste a sessão
   |
   v
Exibe confirmação ao Funcionário
   |
   v
[Fim]
```

---

## 5. Diagrama de Atividade — Registrar Público

```
[Início]
   |
   v
Funcionário seleciona sessão e informa quantidade
   |
   v
Sistema verifica existência da sessão
   |
   v
Sistema calcula total atual de público na sessão
   |
   v
Verifica se (total atual + nova quantidade) <= capacidade do cinema
   |------> [Excede capacidade] --> Exibe erro --> [Fim]
   |
   v
Sistema persiste o registro de público
   |
   v
Exibe confirmação
   |
   v
[Fim]
```

---

## 6. Diagrama de Sequência — Agendar Sessão

```
Funcionário  →  SessaoView  →  SessaoController  →  SessaoService  →  SessaoRepository  →  SQLite

1. Funcionário preenche dados da sessão
2. SessaoView chama controller.cadastrar(cinema_id, filme_id, data, horario, sala)
3. SessaoController chama service.cadastrar(...)
4. SessaoService valida cinema via CinemaRepository.buscar_por_id()
5. SessaoService valida filme via FilmeRepository.buscar_por_id()
6. SessaoService chama sessao_repo.verificar_conflito(...)
7. SessaoRepository executa SELECT no SQLite e retorna resultado
8. Se sem conflito: SessaoService chama sessao_repo.salvar(sessao)
9. SessaoRepository executa INSERT no SQLite, retorna sessao com ID
10. SessaoController retorna {"sucesso": True, "mensagem": ..., "dado": sessao}
11. SessaoView exibe mensagem de confirmação ao Funcionário
```

---

## 7. Diagrama de Sequência — Registrar Público

```
Funcionário  →  RegistroPublicoView  →  RegistroPublicoController  →  RegistroPublicoService  →  RegistroPublicoRepository  →  SQLite

1. Funcionário seleciona sessão e informa quantidade
2. View chama controller.registrar(sessao_id, quantidade)
3. Controller chama service.registrar(sessao_id, quantidade)
4. Service valida sessão via SessaoRepository.buscar_por_id()
5. Service busca capacidade do cinema via CinemaRepository.buscar_por_id()
6. Service chama repo.total_por_sessao(sessao_id) — SELECT SUM no SQLite
7. Service verifica (total + quantidade) <= capacidade
8. Se válido: Service chama repo.salvar(registro)
9. Repository executa INSERT no SQLite e retorna registro com ID
10. Controller retorna {"sucesso": True, "mensagem": ..., "dado": registro}
11. View exibe confirmação ao Funcionário
```

---

## 8. Arquitetura do Projeto

```
cinema/
├── main.py                          # Ponto de entrada da aplicação
├── cinema.db                        # Banco de dados SQLite (gerado em execução)
├── db/
│   └── conexao.py                   # Conexão com SQLite e criação das tabelas
├── model/
│   ├── cinema.py                    # Entidade Cinema
│   ├── filme.py                     # Entidade Filme
│   ├── genero.py                    # Entidade Genero
│   ├── sessao.py                    # Entidade Sessao
│   └── registro_publico.py          # Entidade RegistroPublico
├── repository/
│   ├── cinema_repository.py         # CRUD de Cinema no banco
│   ├── filme_repository.py          # CRUD de Filme no banco
│   ├── genero_repository.py         # CRUD de Genero no banco
│   ├── sessao_repository.py         # CRUD + verificação de conflito de Sessao
│   └── registro_publico_repository.py # CRUD + totalizações de público
├── service/
│   ├── cinema_service.py            # Regras de negócio de Cinema
│   ├── filme_service.py             # Regras de negócio de Filme
│   ├── genero_service.py            # Regras de negócio de Genero
│   ├── sessao_service.py            # Regras de negócio de Sessao (conflito de horário)
│   └── registro_publico_service.py  # Regras de negócio de Público (capacidade)
├── controller/
│   ├── cinema_controller.py         # Recebe chamadas da View, repassa ao Service
│   ├── filme_controller.py
│   ├── sessao_controller.py
│   └── registro_publico_controller.py
└── view/
    ├── cinema_view.py               # Interface de texto (terminal) para Cinema
    ├── filme_view.py                # Interface de texto para Filme
    ├── genero_view.py               # Interface de texto para Genero
    ├── sessao_view.py               # Interface de texto para Sessao
    └── registro_publico_view.py     # Interface de texto para Registro de Público
```

---

## 9. Como Executar

```bash
python main.py
```

Não são necessárias dependências externas. O banco de dados `cinema.db` é criado automaticamente na primeira execução.
