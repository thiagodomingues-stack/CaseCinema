import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from service.registro_publico_service import RegistroPublicoService

class RegistroPublicoController:

    def __init__(self):
        self.service = RegistroPublicoService()

    def registrar(self, sessao_id, quantidade):
        try:
            reg = self.service.registrar(sessao_id, quantidade)
            return {"sucesso": True, "mensagem": f"Público registrado: {reg.quantidade} pessoas.", "dado": reg}
        except ValueError as e:
            return {"sucesso": False, "mensagem": str(e)}

    def total_por_sessao(self, sessao_id):
        try:
            total = self.service.total_por_sessao(sessao_id)
            return {"sucesso": True, "dado": total}
        except Exception as e:
            return {"sucesso": False, "mensagem": str(e)}

    def total_por_filme(self, filme_id):
        try:
            total = self.service.total_por_filme(filme_id)
            return {"sucesso": True, "dado": total}
        except Exception as e:
            return {"sucesso": False, "mensagem": str(e)}

    def total_por_cinema(self, cinema_id):
        try:
            total = self.service.total_por_cinema(cinema_id)
            return {"sucesso": True, "dado": total}
        except Exception as e:
            return {"sucesso": False, "mensagem": str(e)}
