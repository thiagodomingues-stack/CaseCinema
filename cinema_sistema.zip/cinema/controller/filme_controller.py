import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from service.filme_service import FilmeService

class FilmeController:

    def __init__(self):
        self.service = FilmeService()

    def cadastrar(self, titulo, duracao_min, diretor, elenco, genero_id):
        try:
            filme = self.service.cadastrar(titulo, duracao_min, diretor, elenco, genero_id)
            return {"sucesso": True, "mensagem": f"Filme '{filme.titulo}' cadastrado com ID {filme.id}.", "dado": filme}
        except ValueError as e:
            return {"sucesso": False, "mensagem": str(e)}

    def listar(self):
        try:
            filmes = self.service.listar()
            return {"sucesso": True, "dado": filmes}
        except Exception as e:
            return {"sucesso": False, "mensagem": str(e)}

    def buscar(self, filme_id):
        try:
            filme = self.service.buscar(filme_id)
            return {"sucesso": True, "dado": filme}
        except ValueError as e:
            return {"sucesso": False, "mensagem": str(e)}

    def excluir(self, filme_id):
        try:
            self.service.excluir(filme_id)
            return {"sucesso": True, "mensagem": f"Filme ID {filme_id} excluído."}
        except ValueError as e:
            return {"sucesso": False, "mensagem": str(e)}
