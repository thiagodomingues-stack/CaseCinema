import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from service.sessao_service import SessaoService

class SessaoController:

    def __init__(self):
        self.service = SessaoService()

    def cadastrar(self, cinema_id, filme_id, data, horario, sala):
        try:
            sessao = self.service.cadastrar(cinema_id, filme_id, data, horario, sala)
            return {"sucesso": True, "mensagem": f"Sessão cadastrada com ID {sessao.id}.", "dado": sessao}
        except ValueError as e:
            return {"sucesso": False, "mensagem": str(e)}

    def listar_por_cinema(self, cinema_id):
        try:
            sessoes = self.service.listar_por_cinema(cinema_id)
            return {"sucesso": True, "dado": sessoes}
        except Exception as e:
            return {"sucesso": False, "mensagem": str(e)}

    def listar_todas(self):
        try:
            sessoes = self.service.listar_todas()
            return {"sucesso": True, "dado": sessoes}
        except Exception as e:
            return {"sucesso": False, "mensagem": str(e)}

    def buscar(self, sessao_id):
        try:
            sessao = self.service.buscar(sessao_id)
            return {"sucesso": True, "dado": sessao}
        except ValueError as e:
            return {"sucesso": False, "mensagem": str(e)}

    def excluir(self, sessao_id):
        try:
            self.service.excluir(sessao_id)
            return {"sucesso": True, "mensagem": f"Sessão ID {sessao_id} excluída."}
        except ValueError as e:
            return {"sucesso": False, "mensagem": str(e)}
