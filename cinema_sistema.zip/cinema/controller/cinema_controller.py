import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from service.cinema_service import CinemaService

class CinemaController:

    def __init__(self):
        self.service = CinemaService()

    def cadastrar(self, nome, cidade, estado, endereco, capacidade):
        try:
            cinema = self.service.cadastrar(nome, cidade, estado, endereco, capacidade)
            return {"sucesso": True, "mensagem": f"Cinema '{cinema.nome}' cadastrado com ID {cinema.id}.", "dado": cinema}
        except ValueError as e:
            return {"sucesso": False, "mensagem": str(e)}

    def listar(self):
        try:
            cinemas = self.service.listar()
            return {"sucesso": True, "dado": cinemas}
        except Exception as e:
            return {"sucesso": False, "mensagem": str(e)}

    def buscar(self, cinema_id):
        try:
            cinema = self.service.buscar(cinema_id)
            return {"sucesso": True, "dado": cinema}
        except ValueError as e:
            return {"sucesso": False, "mensagem": str(e)}

    def atualizar(self, cinema_id, nome, cidade, estado, endereco, capacidade):
        try:
            cinema = self.service.atualizar(cinema_id, nome, cidade, estado, endereco, capacidade)
            return {"sucesso": True, "mensagem": f"Cinema '{cinema.nome}' atualizado.", "dado": cinema}
        except ValueError as e:
            return {"sucesso": False, "mensagem": str(e)}

    def excluir(self, cinema_id):
        try:
            self.service.excluir(cinema_id)
            return {"sucesso": True, "mensagem": f"Cinema ID {cinema_id} excluído."}
        except ValueError as e:
            return {"sucesso": False, "mensagem": str(e)}
