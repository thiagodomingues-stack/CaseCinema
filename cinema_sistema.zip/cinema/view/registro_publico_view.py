import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from controller.registro_publico_controller import RegistroPublicoController
from service.sessao_service import SessaoService
from service.cinema_service import CinemaService
from service.filme_service import FilmeService

controller = RegistroPublicoController()
sessao_service = SessaoService()
cinema_service = CinemaService()
filme_service = FilmeService()

def menu_registro_publico():
    while True:
        print("\n========== REGISTRO DE PÚBLICO ==========")
        print("1. Registrar Público de uma Sessão")
        print("2. Consultar Total por Sessão")
        print("3. Consultar Total por Filme")
        print("4. Consultar Total por Cinema")
        print("0. Voltar")
        opcao = input("Escolha: ").strip()

        if opcao == "1":
            registrar_publico()
        elif opcao == "2":
            total_por_sessao()
        elif opcao == "3":
            total_por_filme()
        elif opcao == "4":
            total_por_cinema()
        elif opcao == "0":
            break
        else:
            print("Opção inválida.")

def registrar_publico():
    print("\n--- Registrar Público ---")
    sessoes = sessao_service.listar_todas()
    if not sessoes:
        print("Nenhuma sessão cadastrada.")
        return
    print(f"{'ID':<5} {'Cinema':<25} {'Filme':<30} {'Data':<12} {'Hora'}")
    print("-" * 80)
    for s in sessoes:
        print(f"{s.id:<5} {s.cinema_nome:<25} {s.filme_titulo:<30} {s.data:<12} {s.horario}")
    sessao_id = input("ID da Sessão: ").strip()
    quantidade = input("Quantidade de pessoas: ").strip()
    resultado = controller.registrar(sessao_id, quantidade)
    print(f"\n{'✔' if resultado['sucesso'] else '✖'} {resultado['mensagem']}")

def total_por_sessao():
    sessao_id = input("ID da Sessão: ").strip()
    resultado = controller.total_por_sessao(sessao_id)
    if resultado["sucesso"]:
        print(f"\nTotal de público na sessão {sessao_id}: {resultado['dado']} pessoas")
    else:
        print(f"\n✖ {resultado['mensagem']}")

def total_por_filme():
    filmes = filme_service.listar()
    if not filmes:
        print("Nenhum filme cadastrado.")
        return
    for f in filmes:
        print(f"  {f.id} - {f.titulo}")
    filme_id = input("ID do Filme: ").strip()
    resultado = controller.total_por_filme(filme_id)
    if resultado["sucesso"]:
        print(f"\nTotal de público para o filme {filme_id}: {resultado['dado']} pessoas")
    else:
        print(f"\n✖ {resultado['mensagem']}")

def total_por_cinema():
    cinemas = cinema_service.listar()
    if not cinemas:
        print("Nenhum cinema cadastrado.")
        return
    for c in cinemas:
        print(f"  {c.id} - {c.nome} ({c.cidade})")
    cinema_id = input("ID do Cinema: ").strip()
    resultado = controller.total_por_cinema(cinema_id)
    if resultado["sucesso"]:
        print(f"\nTotal de público no cinema {cinema_id}: {resultado['dado']} pessoas")
    else:
        print(f"\n✖ {resultado['mensagem']}")
