import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from service.genero_service import GeneroService

service = GeneroService()

def menu_genero():
    while True:
        print("\n========== GÊNEROS ==========")
        print("1. Cadastrar Gênero")
        print("2. Listar Gêneros")
        print("0. Voltar")
        opcao = input("Escolha: ").strip()

        if opcao == "1":
            descricao = input("Descrição do Gênero: ").strip()
            try:
                g = service.cadastrar(descricao)
                print(f"\n✔ Gênero '{g.descricao}' cadastrado com ID {g.id}.")
            except ValueError as e:
                print(f"\n✖ {e}")
        elif opcao == "2":
            generos = service.listar()
            if not generos:
                print("\nNenhum gênero cadastrado.")
            else:
                print(f"\n{'ID':<5} Descrição")
                print("-" * 25)
                for g in generos:
                    print(f"{g.id:<5} {g.descricao}")
        elif opcao == "0":
            break
        else:
            print("Opção inválida.")
