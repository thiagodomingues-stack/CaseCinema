import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from controller.filme_controller import FilmeController
from service.genero_service import GeneroService

controller = FilmeController()
genero_service = GeneroService()

def menu_filme():
    while True:
        print("\n========== FILMES ==========")
        print("1. Cadastrar Filme")
        print("2. Listar Filmes")
        print("3. Buscar Filme por ID")
        print("4. Excluir Filme")
        print("0. Voltar")
        opcao = input("Escolha: ").strip()

        if opcao == "1":
            cadastrar_filme()
        elif opcao == "2":
            listar_filmes()
        elif opcao == "3":
            buscar_filme()
        elif opcao == "4":
            excluir_filme()
        elif opcao == "0":
            break
        else:
            print("Opção inválida.")

def _escolher_genero():
    generos = genero_service.listar()
    if not generos:
        print("Nenhum gênero cadastrado. Deixe em branco para continuar sem gênero.")
        return None
    print("Gêneros disponíveis:")
    for g in generos:
        print(f"  {g.id} - {g.descricao}")
    genero_id = input("ID do Gênero (Enter para nenhum): ").strip()
    return genero_id if genero_id else None

def cadastrar_filme():
    print("\n--- Cadastrar Filme ---")
    titulo = input("Título: ").strip()
    duracao = input("Duração (minutos): ").strip()
    diretor = input("Diretor: ").strip()
    elenco = input("Elenco (opcional): ").strip()
    genero_id = _escolher_genero()
    resultado = controller.cadastrar(titulo, duracao, diretor, elenco, genero_id)
    print(f"\n{'✔' if resultado['sucesso'] else '✖'} {resultado['mensagem']}")

def listar_filmes():
    resultado = controller.listar()
    filmes = resultado.get("dado", [])
    if not filmes:
        print("\nNenhum filme cadastrado.")
        return
    print(f"\n{'ID':<5} {'Título':<35} {'Duração':<10} {'Diretor':<25} {'Gênero'}")
    print("-" * 85)
    for f in filmes:
        genero = getattr(f, 'genero_descricao', '-') or '-'
        print(f"{f.id:<5} {f.titulo:<35} {f.duracao_min:<10} {f.diretor:<25} {genero}")

def buscar_filme():
    filme_id = input("ID do Filme: ").strip()
    resultado = controller.buscar(filme_id)
    if resultado["sucesso"]:
        f = resultado["dado"]
        genero = getattr(f, 'genero_descricao', '-') or '-'
        print(f"\nID: {f.id} | Título: {f.titulo}")
        print(f"Duração: {f.duracao_min} min | Diretor: {f.diretor}")
        print(f"Elenco: {f.elenco or '-'} | Gênero: {genero}")
    else:
        print(f"\n✖ {resultado['mensagem']}")

def excluir_filme():
    filme_id = input("ID do Filme a excluir: ").strip()
    confirma = input(f"Confirma exclusão do filme ID {filme_id}? (s/n): ").strip().lower()
    if confirma == "s":
        resultado = controller.excluir(filme_id)
        print(f"\n{'✔' if resultado['sucesso'] else '✖'} {resultado['mensagem']}")
