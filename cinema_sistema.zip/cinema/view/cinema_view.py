import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from controller.cinema_controller import CinemaController

controller = CinemaController()

def menu_cinema():
    while True:
        print("\n========== CINEMAS ==========")
        print("1. Cadastrar Cinema")
        print("2. Listar Cinemas")
        print("3. Buscar Cinema por ID")
        print("4. Atualizar Cinema")
        print("5. Excluir Cinema")
        print("0. Voltar")
        opcao = input("Escolha: ").strip()

        if opcao == "1":
            cadastrar_cinema()
        elif opcao == "2":
            listar_cinemas()
        elif opcao == "3":
            buscar_cinema()
        elif opcao == "4":
            atualizar_cinema()
        elif opcao == "5":
            excluir_cinema()
        elif opcao == "0":
            break
        else:
            print("Opção inválida.")

def cadastrar_cinema():
    print("\n--- Cadastrar Cinema ---")
    nome = input("Nome: ").strip()
    cidade = input("Cidade: ").strip()
    estado = input("Estado (sigla): ").strip()
    endereco = input("Endereço completo: ").strip()
    capacidade = input("Capacidade (nº de lugares): ").strip()
    resultado = controller.cadastrar(nome, cidade, estado, endereco, capacidade)
    print(f"\n{'✔' if resultado['sucesso'] else '✖'} {resultado['mensagem']}")

def listar_cinemas():
    resultado = controller.listar()
    cinemas = resultado.get("dado", [])
    if not cinemas:
        print("\nNenhum cinema cadastrado.")
        return
    print(f"\n{'ID':<5} {'Nome':<30} {'Cidade':<20} {'Estado':<8} {'Capacidade'}")
    print("-" * 70)
    for c in cinemas:
        print(f"{c.id:<5} {c.nome:<30} {c.cidade:<20} {c.estado:<8} {c.capacidade}")

def buscar_cinema():
    cinema_id = input("ID do Cinema: ").strip()
    resultado = controller.buscar(cinema_id)
    if resultado["sucesso"]:
        c = resultado["dado"]
        print(f"\nID: {c.id} | Nome: {c.nome} | Cidade: {c.cidade}/{c.estado}")
        print(f"Endereço: {c.endereco} | Capacidade: {c.capacidade}")
    else:
        print(f"\n✖ {resultado['mensagem']}")

def atualizar_cinema():
    cinema_id = input("ID do Cinema a atualizar: ").strip()
    res = controller.buscar(cinema_id)
    if not res["sucesso"]:
        print(f"\n✖ {res['mensagem']}")
        return
    c = res["dado"]
    print(f"(Enter para manter o valor atual)")
    nome = input(f"Nome [{c.nome}]: ").strip() or c.nome
    cidade = input(f"Cidade [{c.cidade}]: ").strip() or c.cidade
    estado = input(f"Estado [{c.estado}]: ").strip() or c.estado
    endereco = input(f"Endereço [{c.endereco}]: ").strip() or c.endereco
    capacidade = input(f"Capacidade [{c.capacidade}]: ").strip() or str(c.capacidade)
    resultado = controller.atualizar(cinema_id, nome, cidade, estado, endereco, capacidade)
    print(f"\n{'✔' if resultado['sucesso'] else '✖'} {resultado['mensagem']}")

def excluir_cinema():
    cinema_id = input("ID do Cinema a excluir: ").strip()
    confirma = input(f"Confirma exclusão do cinema ID {cinema_id}? (s/n): ").strip().lower()
    if confirma == "s":
        resultado = controller.excluir(cinema_id)
        print(f"\n{'✔' if resultado['sucesso'] else '✖'} {resultado['mensagem']}")
