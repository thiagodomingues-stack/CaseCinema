import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from controller.sessao_controller import SessaoController
from service.cinema_service import CinemaService
from service.filme_service import FilmeService

controller = SessaoController()
cinema_service = CinemaService()
filme_service = FilmeService()

def menu_sessao():
    while True:
        print("\n========== SESSÕES ==========")
        print("1. Cadastrar Sessão")
        print("2. Listar Sessões por Cinema")
        print("3. Listar Todas as Sessões")
        print("4. Excluir Sessão")
        print("0. Voltar")
        opcao = input("Escolha: ").strip()

        if opcao == "1":
            cadastrar_sessao()
        elif opcao == "2":
            listar_sessoes_cinema()
        elif opcao == "3":
            listar_todas_sessoes()
        elif opcao == "4":
            excluir_sessao()
        elif opcao == "0":
            break
        else:
            print("Opção inválida.")

def _listar_cinemas_disponiveis():
    cinemas = cinema_service.listar()
    if not cinemas:
        print("Nenhum cinema cadastrado.")
        return None
    print("Cinemas disponíveis:")
    for c in cinemas:
        print(f"  {c.id} - {c.nome} ({c.cidade}/{c.estado})")
    return input("ID do Cinema: ").strip()

def _listar_filmes_disponiveis():
    filmes = filme_service.listar()
    if not filmes:
        print("Nenhum filme cadastrado.")
        return None
    print("Filmes disponíveis:")
    for f in filmes:
        print(f"  {f.id} - {f.titulo} ({f.duracao_min} min)")
    return input("ID do Filme: ").strip()

def cadastrar_sessao():
    print("\n--- Cadastrar Sessão ---")
    cinema_id = _listar_cinemas_disponiveis()
    if not cinema_id:
        return
    filme_id = _listar_filmes_disponiveis()
    if not filme_id:
        return
    data = input("Data (AAAA-MM-DD): ").strip()
    horario = input("Horário (HH:MM): ").strip()
    sala = input("Sala: ").strip()
    resultado = controller.cadastrar(cinema_id, filme_id, data, horario, sala)
    print(f"\n{'✔' if resultado['sucesso'] else '✖'} {resultado['mensagem']}")

def listar_sessoes_cinema():
    cinema_id = _listar_cinemas_disponiveis()
    if not cinema_id:
        return
    resultado = controller.listar_por_cinema(cinema_id)
    _exibir_sessoes(resultado.get("dado", []))

def listar_todas_sessoes():
    resultado = controller.listar_todas()
    _exibir_sessoes(resultado.get("dado", []))

def _exibir_sessoes(sessoes):
    if not sessoes:
        print("\nNenhuma sessão encontrada.")
        return
    print(f"\n{'ID':<5} {'Cinema':<25} {'Filme':<30} {'Data':<12} {'Hora':<8} {'Sala'}")
    print("-" * 90)
    for s in sessoes:
        print(f"{s.id:<5} {s.cinema_nome:<25} {s.filme_titulo:<30} {s.data:<12} {s.horario:<8} {s.sala}")

def excluir_sessao():
    sessao_id = input("ID da Sessão a excluir: ").strip()
    confirma = input(f"Confirma exclusão da sessão ID {sessao_id}? (s/n): ").strip().lower()
    if confirma == "s":
        resultado = controller.excluir(sessao_id)
        print(f"\n{'✔' if resultado['sucesso'] else '✖'} {resultado['mensagem']}")
